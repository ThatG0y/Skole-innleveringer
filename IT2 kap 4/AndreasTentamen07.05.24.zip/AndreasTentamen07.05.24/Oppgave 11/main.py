from klasser.bilkollektiv import Bilkollektiv


def main() -> None:
    kollektiv = Bilkollektiv("Oslo", "Oslo Sentrum")
    kollektiv.run()


if __name__ == "__main__":
    main()
